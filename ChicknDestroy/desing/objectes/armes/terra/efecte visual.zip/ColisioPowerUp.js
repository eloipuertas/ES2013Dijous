﻿var explosion: GameObject;
 
function OnCollisionEnter(){
    var expl = Instantiate(explosion, transform.position, Quaternion.identity);
     Destroy(expl, 3); // delete the explosion after 3 seconds
}
